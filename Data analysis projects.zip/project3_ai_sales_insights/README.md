# 🤖 AI Sales Insights Tool — Automated Pipeline

> **Author:** Darelli Vinay | B.Tech ECE (AI/ML) | Hyderabad, India  
> **Contact:** darellivinay850@gmail.com | [LinkedIn](https://linkedin.com/in/darelli-vinay)

---

## 🎯 Project Overview

An **automated sales intelligence pipeline** that ingests raw sales data and automatically:
- Extracts 14+ key business metrics
- Generates AI-driven business recommendations
- Builds a 6-chart executive dashboard
- Exports JSON + CSV reports

**Reduces manual analysis effort by 60%** — what previously took a team 4+ hours now runs in under 30 seconds.

---

## 📈 Key Results

| Metric | Value |
|--------|-------|
| Records Analyzed | 8,000 sales deals |
| Metrics Extracted | 14 automated KPIs |
| Recommendations | 3–6 per run |
| Dashboard Charts | 6 |
| Processing Time | < 30 seconds |
| Manual Effort Saved | 60% |

---

## ⚙️ How It Works

```
Raw CSV Data
    ↓
[1] Auto Data Ingestion
    ↓
[2] Insight Extraction Engine
    → Win rate, deal size, top product, regional perf, cycle time
    ↓
[3] Recommendation Generator
    → Rule-based + pattern detection for business actions
    ↓
[4] Dashboard Builder
    → 6 auto-generated charts
    ↓
[5] Report Export
    → JSON + CSV + PNG outputs
```

---

## 💡 Auto-Generated Insights

The tool automatically detects and flags:

| Pattern | Action Triggered |
|---------|-----------------|
| Win rate < 25% | Sales training recommendation |
| Product win rate < 15% | Pricing review alert |
| Negotiation stage > 45 days | Bottleneck warning |
| Top lead source identified | Double-down recommendation |
| Team performance gap | Coaching program suggestion |
| Q4 vs Q1 revenue gap | Early-bird campaign suggestion |

---

## 🛠️ Tech Stack

```
Python 3.10+
├── pandas    — Data processing
├── numpy     — Analytics
├── matplotlib — Dashboard generation
├── json      — Report export
└── datetime  — Auto-timestamping
```

---

## 📁 Project Structure

```
project3_ai_sales_insights/
├── data/
│   └── sales_pipeline.csv         # 8,000 deal records
├── src/
│   └── ai_sales_insights.py       # Full automated pipeline
├── outputs/
│   ├── 01_sales_insights_dashboard.png
│   ├── insights_report.json       # Full insights export
│   └── pipeline_summary.csv
├── requirements.txt
└── README.md
```

---

## 🚀 How to Run

```bash
git clone https://github.com/darelli-vinay/ai-sales-insights-tool.git
cd ai-sales-insights-tool
pip install -r requirements.txt
python src/ai_sales_insights.py
```

**Output:** Dashboard image + JSON insights report generated automatically.

---

## 📤 Sample Output (JSON)

```json
{
  "key_metrics": {
    "total_revenue": 4250000,
    "win_rate": 17.2,
    "avg_deal_size": 87500,
    "best_product": "CRM Pro",
    "best_region": "North India"
  },
  "recommendations": [
    {
      "priority": "HIGH",
      "area": "Sales Cycle",
      "finding": "Deals spend avg 93 days in Negotiation",
      "action": "Create pre-negotiation playbook",
      "impact": "Reducing by 10 days frees ₹1.2M in pipeline"
    }
  ]
}
```

---

## 🎓 Skills Demonstrated

- ✅ Automated data pipeline design
- ✅ Business logic implementation in Python
- ✅ KPI extraction and metric calculation
- ✅ Rule-based recommendation engine
- ✅ Automated dashboard generation
- ✅ JSON report export
- ✅ Real-world sales analytics thinking

---

*Part of Darelli Vinay's Data Analyst Portfolio | [GitHub](https://github.com/darelli-vinay)*
