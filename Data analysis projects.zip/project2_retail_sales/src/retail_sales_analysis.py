"""
Retail Sales Data Analysis — Full EDA
======================================
Author : Darelli Vinay
Skills : Python, Pandas, NumPy, Matplotlib, Seaborn, Excel
Dataset: 15,000 retail transactions across 5 categories
Goal   : Identify sales trends, top products, and business recommendations
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches
import seaborn as sns
import warnings, os
warnings.filterwarnings('ignore')

np.random.seed(99)
OUTPUT = "/home/claude/github_projects/project2_retail_sales/outputs"
os.makedirs(OUTPUT, exist_ok=True)

BLUE  = "#1D4ED8"; RED   = "#DC2626"; GREEN = "#16A34A"
AMBER = "#D97706"; GRAY  = "#6B7280"; PURPLE= "#7C3AED"

plt.rcParams.update({
    'figure.facecolor': 'white',
    'axes.facecolor':   '#F9FAFB',
    'axes.spines.top':  False,
    'axes.spines.right':False,
    'axes.grid':        True,
    'grid.color':       '#E5E7EB',
    'grid.linewidth':   0.7,
})

print("=" * 60)
print("  RETAIL SALES DATA ANALYSIS — DARELLI VINAY")
print("=" * 60)

# ── GENERATE REALISTIC DATASET ────────────────────────────────────────────────
N = 15000
dates = pd.date_range("2022-01-01", "2024-12-31", freq='D')
transaction_dates = np.random.choice(dates, N)

categories = {
    'Electronics':  {'price_range':(5000,85000), 'weight':0.18, 'margin':0.22},
    'Clothing':     {'price_range':(299,8999),   'weight':0.28, 'margin':0.48},
    'Groceries':    {'price_range':(50,2500),    'weight':0.30, 'margin':0.18},
    'Home & Living':{'price_range':(299,25000),  'weight':0.14, 'margin':0.35},
    'Sports':       {'price_range':(299,15000),  'weight':0.10, 'margin':0.40},
}

products_map = {
    'Electronics':  ['Smartphone','Laptop','Headphones','Smart TV','Tablet','Smartwatch','Camera'],
    'Clothing':     ['T-Shirt','Jeans','Dress','Jacket','Saree','Kurta','Shoes'],
    'Groceries':    ['Rice (5kg)','Cooking Oil','Dal','Biscuits','Milk','Tea','Spices'],
    'Home & Living':['Bedsheet','Curtains','Cookware','Lamp','Cushion','Wall Art','Storage Box'],
    'Sports':       ['Cricket Bat','Running Shoes','Yoga Mat','Gym Bag','Badminton Set'],
}
cities = ['Hyderabad','Bangalore','Mumbai','Delhi','Pune','Chennai','Kolkata']
cat_weights = [v['weight'] for v in categories.values()]
cat_names   = list(categories.keys())

cat_arr = np.random.choice(cat_names, N, p=cat_weights)
city_arr = np.random.choice(cities, N)
product_arr = [np.random.choice(products_map[c]) for c in cat_arr]
qty_arr  = np.random.choice([1,1,1,2,2,3], N)

unit_price = []
for c in cat_arr:
    lo, hi = categories[c]['price_range']
    unit_price.append(round(np.random.uniform(lo, hi), -1))
unit_price = np.array(unit_price)

# Seasonal multipliers
month_mult = {1:0.85, 2:0.82, 3:0.90, 4:0.88, 5:0.92, 6:0.88,
              7:0.86, 8:0.90, 9:0.95, 10:1.10, 11:1.35, 12:1.25}
discount = np.where(np.random.rand(N) < 0.30, np.random.choice([5,10,15,20,25], N), 0)
transaction_dates_pd = pd.to_datetime(transaction_dates)
seasonal = np.array([month_mult[d.month] for d in transaction_dates_pd])
revenue = np.round(unit_price * qty_arr * (1 - discount/100) * seasonal, 2)
margin_pct = np.array([categories[c]['margin'] for c in cat_arr])
profit = np.round(revenue * margin_pct, 2)

payment_methods = np.random.choice(['UPI','Credit Card','Debit Card','Cash','Net Banking'],
                                    N, p=[0.38, 0.22, 0.20, 0.12, 0.08])
customer_ids = [f"C{np.random.randint(1000, 9999)}" for _ in range(N)]
order_ids = [f"ORD{str(i).zfill(6)}" for i in range(1, N+1)]

df = pd.DataFrame({
    'order_id':         order_ids,
    'date':             transaction_dates_pd,
    'customer_id':      customer_ids,
    'category':         cat_arr,
    'product':          product_arr,
    'city':             city_arr,
    'quantity':         qty_arr,
    'unit_price':       unit_price,
    'discount_pct':     discount,
    'revenue':          revenue,
    'profit':           profit,
    'payment_method':   payment_methods,
})
df['year']  = df['date'].dt.year
df['month'] = df['date'].dt.month
df['month_name'] = df['date'].dt.strftime('%b')
df['quarter'] = df['date'].dt.quarter.map({1:'Q1',2:'Q2',3:'Q3',4:'Q4'})
df['week_day'] = df['date'].dt.day_name()
df['is_weekend'] = df['date'].dt.weekday >= 5

df.to_csv(f"{OUTPUT}/../data/retail_sales_data.csv", index=False)
print(f"\n  Dataset: {len(df):,} transactions | Revenue: ₹{df['revenue'].sum()/1e6:.1f}M")

# ── EDA 1: OVERVIEW DASHBOARD ─────────────────────────────────────────────────
print("\n[1] Building overview dashboard...")
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle("Retail Sales EDA — Overview Dashboard\nDarelli Vinay | Data Analyst Portfolio",
             fontsize=14, fontweight='bold', color=BLUE, y=1.01)

# Revenue by category
ax = axes[0,0]
cat_rev = df.groupby('category')['revenue'].sum().sort_values(ascending=False)
colors_c = [BLUE, AMBER, GREEN, PURPLE, RED]
bars = ax.bar(cat_rev.index, cat_rev.values/1e6, color=colors_c,
              edgecolor='white', linewidth=1.5, width=0.6)
ax.set_title("Revenue by Category (₹M)", fontweight='bold', color=BLUE)
ax.set_ylabel("Revenue (₹ Millions)")
ax.set_xticklabels(cat_rev.index, rotation=15, ha='right', fontsize=8)
for bar, v in zip(bars, cat_rev.values):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.05,
            f"₹{v/1e6:.1f}M", ha='center', fontweight='bold', fontsize=8)

# Monthly revenue trend
ax = axes[0,1]
monthly = df.groupby(['year','month'])['revenue'].sum().reset_index()
monthly['period'] = monthly['year'].astype(str) + '-' + monthly['month'].astype(str).str.zfill(2)
monthly = monthly.sort_values('period')
colors_y = {2022: BLUE, 2023: GREEN, 2024: RED}
for yr in [2022, 2023, 2024]:
    sub = monthly[monthly['year']==yr]
    ax.plot(range(len(sub)), sub['revenue']/1e3, marker='o', markersize=4,
            linewidth=2, color=colors_y[yr], label=str(yr))
ax.set_title("Monthly Revenue Trend (₹K)", fontweight='bold', color=BLUE)
ax.set_ylabel("Revenue (₹ Thousands)")
ax.set_xticks(range(12))
ax.set_xticklabels(['J','F','M','A','M','J','J','A','S','O','N','D'], fontsize=9)
ax.legend(title='Year', fontsize=8)

# Top 10 products
ax = axes[0,2]
top_prod = df.groupby('product')['revenue'].sum().sort_values(ascending=True).tail(10)
colors_p = [BLUE if i >= 7 else AMBER if i >= 4 else GRAY for i in range(10)]
bars = ax.barh(top_prod.index, top_prod.values/1e3, color=colors_p,
               edgecolor='white', linewidth=1)
ax.set_title("Top 10 Products by Revenue (₹K)", fontweight='bold', color=BLUE)
ax.set_xlabel("Revenue (₹K)")
for bar, v in zip(bars, top_prod.values):
    ax.text(bar.get_width()+10, bar.get_y()+bar.get_height()/2,
            f"₹{v/1000:.0f}K", va='center', fontsize=8)

# City performance
ax = axes[1,0]
city_rev = df.groupby('city')['revenue'].sum().sort_values(ascending=False)
bars = ax.bar(city_rev.index, city_rev.values/1e6,
              color=[BLUE, GREEN, AMBER, RED, PURPLE, "#0891B2", "#DC4E12"],
              edgecolor='white', linewidth=1.5, width=0.6)
ax.set_title("Revenue by City (₹M)", fontweight='bold', color=BLUE)
ax.set_ylabel("Revenue (₹ Millions)")
ax.set_xticklabels(city_rev.index, rotation=15, ha='right', fontsize=8)
for bar, v in zip(bars, city_rev.values):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.05,
            f"₹{v/1e6:.1f}M", ha='center', fontweight='bold', fontsize=8)

# Seasonal heatmap
ax = axes[1,1]
pivot = df.pivot_table(values='revenue', index='category',
                       columns='quarter', aggfunc='sum') / 1e3
sns.heatmap(pivot, ax=ax, annot=True, fmt='.0f', cmap='Blues',
            linewidths=0.5, cbar_kws={'label':'Revenue (₹K)'})
ax.set_title("Revenue Heatmap: Category × Quarter (₹K)", fontweight='bold', color=BLUE)
ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
ax.set_yticklabels(ax.get_yticklabels(), rotation=0, fontsize=8)

# Payment methods
ax = axes[1,2]
pay_rev = df.groupby('payment_method')['revenue'].sum()
wedge_colors = [BLUE, GREEN, AMBER, RED, PURPLE]
wedges, texts, autotexts = ax.pie(
    pay_rev.values, labels=pay_rev.index, autopct='%1.1f%%',
    colors=wedge_colors, startangle=90,
    wedgeprops={'edgecolor':'white', 'linewidth':1.5})
for at in autotexts: at.set_fontsize(9); at.set_fontweight('bold')
ax.set_title("Revenue by Payment Method", fontweight='bold', color=BLUE)

plt.tight_layout()
plt.savefig(f"{OUTPUT}/01_overview_dashboard.png", dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: 01_overview_dashboard.png")

# ── EDA 2: SEASONAL ANALYSIS ─────────────────────────────────────────────────
print("\n[2] Seasonal trend analysis...")
fig, axes = plt.subplots(1, 2, figsize=(16, 6))
fig.suptitle("Seasonal Sales Patterns — Retail Analysis\nDarelli Vinay | Data Analyst Portfolio",
             fontsize=13, fontweight='bold', color=BLUE)

month_order = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
month_rev = df.groupby('month_name')['revenue'].sum().reindex(month_order)
colors_m = [RED if v == month_rev.max() else AMBER if v >= month_rev.quantile(0.75)
            else BLUE for v in month_rev.values]
bars = axes[0].bar(month_rev.index, month_rev.values/1e3, color=colors_m,
                   edgecolor='white', linewidth=1.5, width=0.65)
axes[0].set_title("Monthly Revenue Pattern (All Years)", fontweight='bold', color=BLUE)
axes[0].set_ylabel("Revenue (₹ Thousands)")
for bar, v in zip(bars, month_rev.values):
    axes[0].text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
                 f"₹{v/1000:.0f}K", ha='center', fontsize=7.5, fontweight='bold')
axes[0].annotate("Peak: Oct–Dec\n(Festive Season)", xy=(9.5, month_rev.max()*0.95/1e3),
                  xytext=(6, month_rev.max()*0.9/1e3),
                  arrowprops=dict(arrowstyle='->', color=RED),
                  fontsize=9, color=RED, fontweight='bold')

day_rev = df.groupby('week_day')['revenue'].mean()
day_order = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
day_rev = day_rev.reindex(day_order)
colors_d = [RED if d in ['Saturday','Sunday'] else BLUE for d in day_order]
bars2 = axes[1].bar(day_rev.index, day_rev.values, color=colors_d,
                    edgecolor='white', linewidth=1.5, width=0.6)
axes[1].set_title("Average Daily Revenue by Weekday", fontweight='bold', color=BLUE)
axes[1].set_ylabel("Average Revenue per Day (₹)")
axes[1].set_xticklabels(day_order, rotation=15, ha='right')
for bar, v in zip(bars2, day_rev.values):
    axes[1].text(bar.get_x()+bar.get_width()/2, bar.get_height()+100,
                 f"₹{v:,.0f}", ha='center', fontsize=8, fontweight='bold')
weekend_patch = mpatches.Patch(color=RED, label='Weekend')
weekday_patch = mpatches.Patch(color=BLUE, label='Weekday')
axes[1].legend(handles=[weekend_patch, weekday_patch])

plt.tight_layout()
plt.savefig(f"{OUTPUT}/02_seasonal_analysis.png", dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: 02_seasonal_analysis.png")

# ── EDA 3: PROFIT ANALYSIS ────────────────────────────────────────────────────
print("\n[3] Profit margin analysis...")
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("Profit Margin Analysis\nDarelli Vinay | Data Analyst Portfolio",
             fontsize=13, fontweight='bold', color=BLUE)

cat_profit = df.groupby('category').agg(
    revenue=('revenue','sum'), profit=('profit','sum')).reset_index()
cat_profit['margin'] = cat_profit['profit'] / cat_profit['revenue'] * 100

x = np.arange(len(cat_profit))
w = 0.35
b1 = axes[0].bar(x - w/2, cat_profit['revenue']/1e6, w, label='Revenue', color=BLUE,
                  edgecolor='white', linewidth=1.2)
b2 = axes[0].bar(x + w/2, cat_profit['profit']/1e6, w, label='Profit', color=GREEN,
                  edgecolor='white', linewidth=1.2)
axes[0].set_title("Revenue vs Profit by Category (₹M)", fontweight='bold', color=BLUE)
axes[0].set_xticks(x)
axes[0].set_xticklabels(cat_profit['category'], rotation=15, ha='right', fontsize=8)
axes[0].set_ylabel("Amount (₹ Millions)")
axes[0].legend()

colors_m2 = [GREEN if m > 35 else AMBER if m > 25 else RED for m in cat_profit['margin']]
bars3 = axes[1].bar(cat_profit['category'], cat_profit['margin'],
                    color=colors_m2, edgecolor='white', linewidth=1.5, width=0.5)
axes[1].set_title("Profit Margin % by Category", fontweight='bold', color=BLUE)
axes[1].set_ylabel("Profit Margin (%)")
axes[1].set_xticklabels(cat_profit['category'], rotation=15, ha='right', fontsize=8)
for bar, v in zip(bars3, cat_profit['margin']):
    axes[1].text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.3,
                 f"{v:.1f}%", ha='center', fontweight='bold', fontsize=10)

plt.tight_layout()
plt.savefig(f"{OUTPUT}/03_profit_analysis.png", dpi=150, bbox_inches='tight')
plt.close()
print("    Saved: 03_profit_analysis.png")

# ── SUMMARY ───────────────────────────────────────────────────────────────────
total_rev   = df['revenue'].sum()
total_prof  = df['profit'].sum()
top_cat     = cat_rev.index[0]
peak_month  = month_rev.idxmax()
top_city    = city_rev.index[0]
top_product = df.groupby('product')['revenue'].sum().idxmax()

print("\n" + "="*60)
print("  RETAIL SALES ANALYSIS — KEY FINDINGS")
print("="*60)
print(f"  Total Revenue (3 yrs):  ₹{total_rev/1e6:.2f}M")
print(f"  Total Profit:           ₹{total_prof/1e6:.2f}M")
print(f"  Overall Margin:         {total_prof/total_rev:.1%}")
print(f"  Top Category:           {top_cat}")
print(f"  Peak Month:             {peak_month} (Festive season)")
print(f"  Top City:               {top_city}")
print(f"  Top Product:            {top_product}")
print(f"  Weekend vs Weekday:     +{(df[df['is_weekend']]['revenue'].mean()/df[~df['is_weekend']]['revenue'].mean()-1):.1%} higher on weekends")
print("="*60)
print("\n  Outputs: 01_overview_dashboard.png | 02_seasonal_analysis.png | 03_profit_analysis.png")

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
wb = openpyxl.Workbook()
ws = wb.active; ws.title = "Summary"
summary_data = [
    ["Retail Sales Analysis Summary", ""],
    ["Analyst", "Darelli Vinay"],
    ["Dataset", "15,000 retail transactions (2022–2024)"],
    ["Total Revenue", f"₹{total_rev/1e6:.2f}M"],
    ["Total Profit", f"₹{total_prof/1e6:.2f}M"],
    ["Overall Margin", f"{total_prof/total_rev:.1%}"],
    ["Top Category", top_cat],
    ["Peak Month", peak_month],
    ["Top City", top_city],
    ["Top Product", top_product],
]
for row in summary_data:
    ws.append(row)
ws["A1"].font = Font(bold=True, size=13, color="FFFFFF")
ws["A1"].fill = PatternFill("solid", fgColor="1D4ED8")
ws.column_dimensions["A"].width = 22
ws.column_dimensions["B"].width = 35
wb.save(f"{OUTPUT}/sales_summary.xlsx")
print("  Saved: sales_summary.xlsx")
